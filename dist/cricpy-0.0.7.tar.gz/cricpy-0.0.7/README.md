# Pyc 

## Description: 

Tools for analyzing performances of cricketers based on stats in
ESPN Cricinfo Statsguru. The toolset can  be used for analysis of Tests,ODIs 
and Twenty20 matches of both batsmen and bowlers.